# Station 3 · References for the espresso machine

The director has added a line to the funding application:

**“The scientific literature supports our investment.”**

Underneath it, someone has typed: **[references needed]**.

**Your mission:** Use an AI agent to write the scientific-background paragraph
for the proposal, using the two supplied papers. Keep it under 100 words and
include references that a colleague can follow.

## Fill the gap · 13:40–14:00

Open the shared story and the two papers. Give the agent the task and the source
material. Work with it until the paragraph is ready for your team's meeting.

**Files to give your agent:** study-story.md, study-description.md and papers.md. Open the original-source links in papers.md; if access fails, use offline-source-cards.md.

**Need a start?** “Write the scientific background for our institute's coffee
study and espresso-machine proposal using these two papers. Keep it under
100 words and cite the sources.”

Read the first version together. Would it help someone understand why the study
is worth doing? Ask for a revision if you want one.

Bring one sentence you would put your name to. If you get stuck, ask your
facilitator for help.
