# The Espresso Study: study description

This is a fictional randomized study with two groups. All records are synthetic. They contain no real personal or clinical data. For the exercise, act as the institute's study team.

## Question and design
Does assignment to caffeinated coffee shorten the time to first manuscript acceptance compared with decaffeinated coffee?
The study randomly assigns 60 researchers to two groups of 30. The coffee supplies look alike and carry codes. Participants and the coordinator recording acceptances are meant to remain unaware of the assignments. The exported data identify each group for analysis.

Both groups are offered two standard servings of their assigned coffee per working day for a year. These are fictional study details, not health advice. The dataset does not record whether researchers followed the plan or consumed other caffeine. Analyse everyone in their assigned group.

## Outcome and follow-up
The study measures calendar days from randomization to the first journal acceptance of a manuscript on which the researcher is an author. The manuscript may already have been in progress at randomization. Only acceptances after randomization count. Submission and online publication dates are not the outcome.
Randomization is day 0. Follow-up ends on day 365. An acceptance on day 365 counts as an event. Researchers without an acceptance are right-censored on day 365. This means they were still waiting when observation ended; their later acceptance time is unknown.

For simplicity, nobody withdraws, dies or is lost to follow-up. Assume that the study records every acceptance during follow-up. The dataset has no baseline characteristics or secondary outcomes. It does not record manuscript stage or journal choice. These are stated simplifications of the exercise.
