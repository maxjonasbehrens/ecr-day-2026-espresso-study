# Export guide — synthetic workshop study
One participant per researcher_id; two files join by that key, not row order.
Trim whitespace from identifiers. Dates use YYYY-MM-DD. Randomization is day 0.
Yes/1 means the first manuscript acceptance was observed; No/0 means none was observed.
Blank or NA acceptance_date is expected if no acceptance occurred. Do not invent an event date.
Follow-up ends at 365 days after randomization for everyone without an acceptance.
For an acceptance, elapsed days run from randomization to acceptance; otherwise to followup_end_date.
An acceptance on day 365 counts as an event. Keep one row per randomized researcher.
All coffee labels refer to randomized assignments. No real people or observed trial results.
