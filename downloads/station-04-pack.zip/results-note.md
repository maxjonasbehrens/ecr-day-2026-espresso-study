# Prepared results — fictional coffee study

Randomized caffeine versus decaffeinated coffee, 30 researchers per arm. Follow-up: 365 days from randomization. Event: first manuscript acceptance, not submission or online publication.
All records are invented for this workshop. The allocation is random in the simulator; effects are assumptions, not evidence from the caffeine papers.
Kaplan–Meier curves estimate the proportion still awaiting acceptance. Lower curves indicate earlier acceptance. Shading is an approximate 95% log-log Greenwood confidence interval for each curve. Plus marks indicate censoring; coincident marks at day 365 overlap.
Only administrative censoring at day 365 occurs. No log-rank test, hazard ratio, adjusted comparison, confidence interval for the group difference, or cost analysis was performed.

| Group | Randomized | Accepted by day 365 | Still waiting/censored | Estimated median days to acceptance |
|---|---:|---:|---:|---:|
| caffeinated | 30 | 19 | 11 | 176 |
| decaffeinated | 30 | 19 | 11 | 226 |

Participants still waiting were included until day 365.
