# Station 1 · Prepare the data

The study coordinator sends two files and a message:

**"Here are the coffee groups and the manuscript follow-up. The director wants results before the next budget meeting. Can you prepare the data?"**

**Your task:** Use an AI agent to prepare a table for comparing time to first manuscript acceptance between the coffee groups. Add a short handover note so a colleague can use it.

## Prepare the table · 13:40 to 14:00

Read the study description and export guide. Give the agent the files below and explain the task. Work with it until you have a usable table and handover note.

**Files to give your agent:** study-story.md, study-description.md, export-guide.md, participants.csv and followup.csv.

**Suggested first prompt:** "Prepare these study exports for a colleague analysing time to first manuscript acceptance. Use the study description and export guide. Return an analysis table and a short handover note."

Read the output as if you were the colleague receiving it. Ask for any changes that would help you use it.

For the station report, show the table and share the most useful sentence from your handover. Ask your facilitator if you get stuck.
