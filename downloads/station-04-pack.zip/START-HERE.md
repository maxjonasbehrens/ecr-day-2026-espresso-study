# Station 4 · Reply before the machine sells out

The results have arrived. So has a message from the director:

**“Excellent. Can we order it now?”**

**Your mission:** Work with an AI agent to write the reply. Give the director
a recommendation in no more than 120 words, with a headline they will remember.

## Write the reply · 13:40–14:00

Open the shared story, the prepared results figure and its accompanying results
note. Give the agent the task and the material it needs. Work with it until you
have a reply you would send as the study team.

**Files to give your agent:** study-story.md, study-description.md, figure.png and results-note.md.

**Need a start?** “Our director wants to know whether these study results justify
buying the espresso machine. Draft a short recommendation using the supplied
study description and results. Include a memorable headline.”

Read the draft together. Does it say what your team wants to say? You can ask
for a revision, question the recommendation, or keep it as it stands.

Bring your headline and recommendation to the meeting. If you get stuck, ask
your facilitator for help.
