# Two papers for the proposal

Read the original abstracts first; the second paper also has accessible full text. These are the two assigned sources, not a systematic literature review.

1. Zabelina DL, Silvia PJ (2020). Percolating ideas: The effects of caffeine on creative thinking and problem solving. Consciousness and Cognition 79:102899. DOI: 10.1016/j.concog.2020.102899.
Original abstract: https://pubmed.ncbi.nlm.nih.gov/32086187/
Publisher: https://doi.org/10.1016/j.concog.2020.102899

2. Stepan ME, Altmann EM, Fenn KM (2021). Caffeine selectively mitigates cognitive deficits caused by sleep deprivation. Journal of Experimental Psychology: Learning, Memory, and Cognition 47(9):1371–1382. DOI: 10.1037/xlm0001023.
Original full text: https://pmc.ncbi.nlm.nih.gov/articles/PMC12884582/

If PubMed returns no readable text, try the publisher DOI link above. If internet access fails, use offline-source-cards.md. It contains short original excerpts and explicitly labelled editorial context, not full articles. Claims outside those excerpts still require the original source.
