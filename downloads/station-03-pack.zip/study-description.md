# The Espresso Study — study description

Fictional randomized parallel-group study. All records are synthetic; no real people or clinical observations are represented. Within this exercise, act as the institute's study team.

## Question and design
Does assignment to caffeinated rather than decaffeinated coffee shorten the time to first manuscript acceptance?
Sixty researchers are allocated 1:1 (30 per group). The study uses matching coded coffee supplies. Participants and the coordinator recording acceptances are intended to remain unaware of allocation. The data export contains decoded assignments for analysis.

For the story, both groups are offered two standardized servings of their assigned coffee per working day for a year. These are fictional protocol details, not health advice. Compliance and other caffeine consumption were not recorded in this teaching dataset. Analyse researchers in their randomized group.

## Outcome and follow-up
The only outcome is calendar days from randomization to first journal acceptance of a manuscript on which the researcher is an author. The manuscript may have been in progress at randomization; only acceptances after randomization count. Submission and online publication dates are not the endpoint.
Randomization is day 0. Follow-up ends at day 365. An acceptance on day 365 counts as an event. If no acceptance is observed, the researcher is right-censored at day 365: observed still waiting up to then, subsequent time unknown.

For simplicity, there are no withdrawals, deaths or losses to follow-up. All acceptances within follow-up are assumed captured. There are no baseline covariates or secondary endpoints. Manuscript stage and journal choice were not collected. These simplifications are known study facts, not hidden issues to discover.
