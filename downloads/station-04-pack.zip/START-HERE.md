# Station 4 · Write the reply

The study results have arrived, along with a message from the director:

**"Excellent. Can we order it now?"**

**Your task:** Use an AI agent to write a recommendation in no more than 120 words. Give it a memorable headline.

## Write the reply · 13:40 to 14:00

Read the study description, results note and figure. Give the agent the files below and explain the task. Work with it until you have a reply you would send.

**Files to give your agent:** study-story.md, study-description.md, figure.png and results-note.md.

**Suggested first prompt:** "Do these study results justify buying the espresso machine? Draft a short recommendation to our director using the supplied study description and results. Include a memorable headline."

Read the draft together. Does it say what your team wants to say? You can question the recommendation, ask for changes or keep it.

For the station report, share your headline and recommendation. Ask your facilitator if you get stuck.
