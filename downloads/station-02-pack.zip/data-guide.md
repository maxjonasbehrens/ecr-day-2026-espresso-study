# Analysis table

One row per randomized researcher; all records are synthetic.

- researcher_id: unique record key.
- coffee_group: randomized assignment, caffeinated or decaffeinated.
- days: elapsed calendar days from randomization to first manuscript acceptance if accepted=1; otherwise days to end of observation.
- accepted: 1 = observed first acceptance at that time; 0 = observation ended without acceptance.

Read study-description.md for the outcome and follow-up rules. A value of 365 with accepted=0 is not an acceptance at day 365. There are no missing values in this prepared table.
