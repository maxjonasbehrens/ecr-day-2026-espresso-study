# Station 3 · Find the evidence

The director has added a line to the funding application:

**"The scientific literature supports our investment."**

Below it, someone has typed: **[references needed]**.

**Your task:** Use an AI agent and the two papers to write a background paragraph for the proposal. Use fewer than 100 words and include references your colleagues can look up.

## Write the background · 13:40 to 14:00

Read the study description and open the two papers using the links in papers.md. Give the agent the task and sources. Work with it until the paragraph is ready for the meeting.

**Files to give your agent:** study-story.md, study-description.md and papers.md. If you cannot open the papers, use offline-source-cards.md.

**Suggested first prompt:** "Write the background for our institute's coffee study and proposed espresso-machine purchase. Use these two papers. Keep it under 100 words and cite the sources."

Read the draft together. Does it explain why the study is worth doing? Ask for changes if needed.

For the station report, share one sentence you would put your name to. Ask your facilitator if you get stuck.
