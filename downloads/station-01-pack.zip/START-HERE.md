# Station 1 · Before the first sip of statistics

The study coordinator sends two files and a message:

**“Here are the coffee groups and the manuscript follow-up. The director wants
results before the next budget meeting. Can you make this usable?”**

**Your mission:** Work with an AI agent to prepare a dataset a colleague can use
to compare time to first manuscript acceptance between the coffee groups.
Include a short handover note explaining what your colleague needs to know.

## Prepare the handover · 13:40–14:00

Open the shared story, the export guide and the two data files. Give the agent
your task and the material it needs. Work with it until you have a usable table
and handover note.

**Files to give your agent:** study-story.md, study-description.md, export-guide.md, participants.csv and followup.csv.

**Need a start?** “Prepare these study exports for a colleague analysing time to
first manuscript acceptance. Use the study description and export guide. Return
the analysis table and a short handover note.”

Read the result as if you were the colleague receiving it. If something would
make your next step easier, ask for it.

Bring the table and the most useful sentence from your handover to the station
report. If you get stuck, ask your facilitator for help.
