# Export guide: synthetic study data
Each file has one row per researcher_id. Join the files using this key, not their row order.
Remove spaces around identifiers. Dates use YYYY-MM-DD. Randomization is day 0.
Yes or 1 means a first manuscript acceptance was observed. No or 0 means none was observed.
A blank or NA acceptance_date is expected when no acceptance occurred. Do not invent a date.
For researchers without an acceptance, observation ends 365 days after randomization.
For an acceptance, calculate days from randomization to acceptance_date. Otherwise, calculate days from randomization to followup_end_date.
An acceptance on day 365 counts as an event. Keep one row per randomized researcher.
Coffee labels identify the assigned groups. All records are fictional.
