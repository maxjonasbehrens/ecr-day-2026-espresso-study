# Two papers for the proposal

Start with the abstracts. You can also read the full text of the second paper. This task uses two selected papers; it is not a systematic literature review.

1. Zabelina DL, Silvia PJ (2020). Percolating ideas: The effects of caffeine on creative thinking and problem solving. Consciousness and Cognition 79:102899. DOI: 10.1016/j.concog.2020.102899.
Original abstract: https://pubmed.ncbi.nlm.nih.gov/32086187/
Publisher: https://doi.org/10.1016/j.concog.2020.102899

2. Stepan ME, Altmann EM, Fenn KM (2021). Caffeine selectively mitigates cognitive deficits caused by sleep deprivation. Journal of Experimental Psychology: Learning, Memory, and Cognition 47(9):1371–1382. DOI: 10.1037/xlm0001023.
Original full text: https://pmc.ncbi.nlm.nih.gov/articles/PMC12884582/

If PubMed does not display the abstract, try the publisher link above. If you cannot access either source, use offline-source-cards.md. It contains short quotes and labelled summaries, not full papers. Check claims beyond those quotes in the original paper.
