# Station 2 · Show the results

The director has left a space in the funding application for the espresso machine:

**"Insert convincing figure here."**

**Your task:** Use an AI agent to create a clear, convincing figure of the study results for the institute meeting. Explain the result in two sentences.

## Make the figure · 13:40 to 14:00

Read the study description and data guide. Give the agent the files below and explain the task. Work with it until you have a figure you would present.

**Files to give your agent:** study-story.md, study-description.md, data-guide.md and analysis.csv.

**Suggested first prompt:** "Create a figure showing this study's results for our institute meeting. Use the attached data and study description. Run the analysis and explain what the figure shows."

Give the figure a headline. For the station report, show the figure and explain what it means for the proposed purchase.

Ask your facilitator if you get stuck.
