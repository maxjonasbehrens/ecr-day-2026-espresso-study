# The Espresso Study

The institute wants an expensive espresso machine. The director hopes to pay for it with research funding.

The justification is ready:

**"Better coffee. Better research. Faster papers."**

Now the director wants evidence. In a study, researchers are randomly assigned to caffeinated or decaffeinated coffee for a year. The team records the time until each researcher's first manuscript is accepted by a journal.

You are the research team. Use an AI agent to find out whether the study supports the purchase. Your team decides what to conclude.

**The study question:** Does caffeinated coffee shorten the time to first manuscript acceptance compared with decaffeinated coffee?

If a researcher is still waiting for an acceptance at the end of the year, we know how long they have waited. We do not know when an acceptance will happen.

The study and data are fictional. For the exercise, treat the supplied results as the institute's findings. Base your recommendation on those findings.
