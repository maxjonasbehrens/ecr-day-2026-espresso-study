# Station 2 · Show the results

The director has left a space in the funding application for the espresso machine:

**"Insert convincing figure here."**

**Your task:** Use an AI agent to create a clear, convincing figure of the study results for the institute meeting. Explain the result in two sentences.

## Make the figure · until 14:00

Read the study description and data guide. Give the agent the files below and explain the task. Work with it until you have a figure you would present.

**Files to give your agent:** study-story.md, study-description.md, data-guide.md and analysis.csv.

**Suggested first prompt:** "Create a figure showing this study's results for our institute meeting. Use the attached data and study description. Run the analysis and explain what the figure shows."

Give the figure a headline. Keep your result and conversation open: at 14:00 the website shows two questions to check it.

Stuck? From 13:50 the website offers a prepared figure, or ask a facilitator.
