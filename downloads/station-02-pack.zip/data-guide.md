# Analysis table

Each row is one randomized researcher. All records are synthetic.

- researcher_id: unique researcher identifier.
- coffee_group: assigned coffee, caffeinated or decaffeinated.
- days: days from randomization to first manuscript acceptance when accepted=1. When accepted=0, it is the number of days observed without acceptance.
- accepted: 1 means an acceptance occurred at that time. 0 means observation ended without an acceptance.

Read study-description.md for the study rules. A row with days=365 and accepted=0 means the researcher was still waiting on day 365. The table has no missing values.
