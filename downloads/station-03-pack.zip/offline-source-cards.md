# Offline source cards

Use these short extracts if you cannot access the papers. They are not complete abstracts or articles. The sections labelled "Editorial context" summarise the papers in our words. Only the passages marked as quotes reproduce the authors' wording. Sources checked 17 September 2026.

## Zabelina & Silvia (2020)
Reference and original: https://pubmed.ncbi.nlm.nih.gov/32086187/ · DOI 10.1016/j.concog.2020.102899

Editorial context: A randomized, blinded laboratory comparison assigned 44 participants to 200 mg caffeine and 44 to placebo. Outcomes included convergent problem solving, divergent idea generation and working memory. The abstract reports better problem-solving performance in the caffeine group.

Original excerpt, Abstract, sentence beginning “Caffeine had…”:
> Caffeine had no significant effects on creative generation or on working memory.

## Stepan, Altmann & Fenn (2021)
Reference and original: https://pmc.ncbi.nlm.nih.gov/articles/PMC12884582/ · DOI 10.1037/xlm0001023

Editorial context: The experiment included 276 participants, overnight wakefulness versus sleep conditions, and 200 mg caffeine versus placebo. The tasks assessed sustained attention and keeping one's place in a sequence. The quoted result concerns impairment associated with sleep deprivation.

Original excerpt, Abstract, sentence beginning “Caffeine counteracted…” (opening clause):
> Caffeine counteracted this impairment in vigilant attention but did not significantly affect placekeeping for most participants

The remainder of that sentence notes fewer sleep-deprived participants falling below the accuracy criterion. Consult the original for the full context. You can check only the claims covered by these extracts. If your main claim goes further and you cannot open the paper, mark it as unverified.
