# Espresso yourself into print?

The institute has fallen in love with an espresso machine. Unfortunately, it is
expensive. Fortunately, there is still some research funding.

The director already has the justification:

**“Better coffee. Better research. Faster papers.”**

A study is supposed to provide the evidence. Researchers are randomly assigned
to caffeinated or decaffeinated coffee for a year. The team records how long it
takes until each person's first manuscript is accepted by a journal.

You are the research team. Your job is to find out whether the evidence supports
the director's favourite purchase. The conclusion is yours.

**The shared question:** Does caffeinated coffee shorten the time to manuscript
acceptance compared with decaffeinated coffee?

**One detail:** If a manuscript has not been accepted by the end of the year,
we know how long the researcher has waited—not how much longer they will wait.

This is a fictional study with synthetic data. Within the exercise, treat the
supplied results as the institute's study findings. Your recommendation should
turn on what the study supports, rather than on the fact that this is a simulation.
