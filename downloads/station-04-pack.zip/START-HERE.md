# Station 4 · Write the reply

The study results have arrived, along with a message from the director:

**"Excellent. Can we order it now?"**

**Your task:** Use an AI agent to write a recommendation in no more than 120 words. Give it a memorable headline.

## Write the reply · until 14:00

Read the study description, results note and figure. Give the agent the files below and explain the task. Work with it until you have a reply you would send.

**Files to give your agent:** study-story.md, study-description.md, figure.png and results-note.md.

**Suggested first prompt:** "Do these study results justify buying the espresso machine? Draft a short recommendation to our director using the supplied study description and results. Include a memorable headline."

Read the draft together. Does it say what your team wants to say? You can question the recommendation, ask for changes or keep it.

Keep your result and conversation open: at 14:00 the website shows two questions to check it. Stuck? Ask a facilitator.
