# Station 2 · Show us the papers

The director has left a space in the espresso-machine funding application:

**“Insert convincing figure here.”**

**Your mission:** Use an AI agent to create a clear, convincing figure of the
study results for the institute meeting. Add a two-sentence interpretation.

## Make the figure · 13:40–14:00

Open the shared story and the prepared analysis table. Give the agent your task
and the material it needs. Work with it until you have a result you would present.

**Files to give your agent:** study-story.md, study-description.md, data-guide.md and analysis.csv.

**Need a start?** “We need a figure showing the results of this study for our
institute meeting. Use the attached data and study description, run the analysis,
and explain what the figure shows.”

Choose a headline for your figure. Be ready to show the result and explain what
you think it means for the espresso-machine proposal.

If you get stuck, ask your facilitator for help.
